## Contains things I find usefull in my Mahcine Learning work

## Something not working?/Found somthing fishy? Open an issue please!

When writing the issue mention what file are you having problems running and the actual error/problem.


</br>

[Learning Tensorflow 2.0+](https://github.com/gmihaila/machine_learning_things/tree/master/learning_tensorflow)
